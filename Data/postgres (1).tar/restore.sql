--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: affectedproducts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.affectedproducts (
    product_id integer NOT NULL,
    vulnerability_id character varying(255),
    product_name character varying(255),
    version character varying(100)
);


ALTER TABLE public.affectedproducts OWNER TO postgres;

--
-- Name: affectedproducts_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.affectedproducts_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.affectedproducts_product_id_seq OWNER TO postgres;

--
-- Name: affectedproducts_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.affectedproducts_product_id_seq OWNED BY public.affectedproducts.product_id;


--
-- Name: referencedata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.referencedata (
    reference_id integer NOT NULL,
    vulnerability_id character varying(255),
    url character varying(255),
    description text
);


ALTER TABLE public.referencedata OWNER TO postgres;

--
-- Name: referencedata_reference_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.referencedata_reference_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.referencedata_reference_id_seq OWNER TO postgres;

--
-- Name: referencedata_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.referencedata_reference_id_seq OWNED BY public.referencedata.reference_id;


--
-- Name: vulnerabilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vulnerabilities (
    vulnerability_id character varying(255) NOT NULL,
    description text,
    published_date date,
    severity text,
    required_action text,
    CONSTRAINT vulnerability_id_format CHECK (((vulnerability_id)::text ~ '^CVE-[0-9]{4}-[0-9]{4,19}$'::text))
);


ALTER TABLE public.vulnerabilities OWNER TO postgres;

--
-- Name: affectedproducts product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.affectedproducts ALTER COLUMN product_id SET DEFAULT nextval('public.affectedproducts_product_id_seq'::regclass);


--
-- Name: referencedata reference_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referencedata ALTER COLUMN reference_id SET DEFAULT nextval('public.referencedata_reference_id_seq'::regclass);


--
-- Data for Name: affectedproducts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.affectedproducts (product_id, vulnerability_id, product_name, version) FROM stdin;
\.
COPY public.affectedproducts (product_id, vulnerability_id, product_name, version) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: referencedata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.referencedata (reference_id, vulnerability_id, url, description) FROM stdin;
\.
COPY public.referencedata (reference_id, vulnerability_id, url, description) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: vulnerabilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vulnerabilities (vulnerability_id, description, published_date, severity, required_action) FROM stdin;
\.
COPY public.vulnerabilities (vulnerability_id, description, published_date, severity, required_action) FROM '$$PATH$$/3366.dat';

--
-- Name: affectedproducts_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.affectedproducts_product_id_seq', 1, false);


--
-- Name: referencedata_reference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.referencedata_reference_id_seq', 1, false);


--
-- Name: affectedproducts affectedproducts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.affectedproducts
    ADD CONSTRAINT affectedproducts_pkey PRIMARY KEY (product_id);


--
-- Name: referencedata referencedata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referencedata
    ADD CONSTRAINT referencedata_pkey PRIMARY KEY (reference_id);


--
-- Name: vulnerabilities vulnerabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vulnerabilities
    ADD CONSTRAINT vulnerabilities_pkey PRIMARY KEY (vulnerability_id);


--
-- Name: affectedproducts affectedproducts_vulnerability_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.affectedproducts
    ADD CONSTRAINT affectedproducts_vulnerability_id_fkey FOREIGN KEY (vulnerability_id) REFERENCES public.vulnerabilities(vulnerability_id);


--
-- Name: referencedata referencedata_vulnerability_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referencedata
    ADD CONSTRAINT referencedata_vulnerability_id_fkey FOREIGN KEY (vulnerability_id) REFERENCES public.vulnerabilities(vulnerability_id);


--
-- PostgreSQL database dump complete
--

